package com.localadb.manager.ui

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.localadb.manager.ThemePreference
import com.localadb.manager.adb.AdbConnectionState
import com.localadb.manager.adb.AdbRepository
import com.localadb.manager.adb.InstalledApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Одна запись в истории терминала: команда и её вывод. */
data class TerminalEntry(val command: String, val output: String)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AdbRepository(application)
    private val themePreference = ThemePreference(application)

    val connectionState: StateFlow<AdbConnectionState> = repository.state

    private val _isInstalling = MutableStateFlow(false)
    val isInstalling: StateFlow<Boolean> = _isInstalling.asStateFlow()

    private val _installResult = MutableStateFlow<String?>(null)
    val installResult: StateFlow<String?> = _installResult.asStateFlow()

    private val _isReconnecting = MutableStateFlow(false)
    val isReconnecting: StateFlow<Boolean> = _isReconnecting.asStateFlow()

    private val _darkMode = MutableStateFlow(themePreference.get())
    val darkMode: StateFlow<Boolean?> = _darkMode.asStateFlow()

    private val _apps = MutableStateFlow<List<InstalledApp>>(emptyList())
    val apps: StateFlow<List<InstalledApp>> = _apps.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    private val _appsError = MutableStateFlow<String?>(null)
    val appsError: StateFlow<String?> = _appsError.asStateFlow()

    private val _terminalHistory = MutableStateFlow<List<TerminalEntry>>(emptyList())
    val terminalHistory: StateFlow<List<TerminalEntry>> = _terminalHistory.asStateFlow()

    private val _isRunningCommand = MutableStateFlow(false)
    val isRunningCommand: StateFlow<Boolean> = _isRunningCommand.asStateFlow()

    init {
        // Если раньше уже сопрягались — пробуем подключиться автоматически, без ввода кода
        if (repository.hasSavedPairing()) {
            viewModelScope.launch { repository.reconnect() }
        }
    }

    fun pair(code: String) {
        viewModelScope.launch { repository.pairAndConnect(code) }
    }

    /** Ручное переподключение — например, если Wi-Fi моргнул и соединение отвалилось. */
    fun retryConnect() {
        viewModelScope.launch {
            _isReconnecting.value = true
            repository.reconnect()
            _isReconnecting.value = false
        }
    }

    fun forgetPairing() {
        repository.forgetPairing()
    }

    fun setDarkMode(value: Boolean?) {
        themePreference.set(value)
        _darkMode.value = value
    }

    /** Загружает подробный список сторонних приложений (версия, размер, дата установки). */
    fun loadApps() {
        viewModelScope.launch {
            _isLoadingApps.value = true
            _appsError.value = null
            val result = repository.listInstalledAppsDetailed()
            result.fold(
                onSuccess = { _apps.value = it },
                onFailure = { _appsError.value = "Не удалось получить список: ${it.message}" },
            )
            _isLoadingApps.value = false
        }
    }

    fun uninstallApp(packageName: String) {
        viewModelScope.launch {
            val result = repository.uninstallPackage(packageName)
            if (result.isSuccess) {
                _apps.value = _apps.value.filterNot { it.packageName == packageName }
            } else {
                _appsError.value = "Не удалось удалить $packageName: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    /** Выполняет произвольную команду в терминале и добавляет запись в историю. */
    fun runTerminalCommand(command: String) {
        viewModelScope.launch {
            _isRunningCommand.value = true
            val result = repository.runRawCommand(command)
            val output = result.fold(
                onSuccess = { it.ifBlank { "(пусто)" } },
                onFailure = { "Ошибка: ${it.message}" },
            )
            _terminalHistory.value = _terminalHistory.value + TerminalEntry(command, output)
            _isRunningCommand.value = false
        }
    }

    /** Вызывается после того, как пользователь выбрал APK через системный диалог. */
    fun onApkPicked(uri: Uri, contentResolver: ContentResolver) {
        viewModelScope.launch {
            _installResult.value = null
            _isInstalling.value = true

            val outcome = withContext(Dispatchers.IO) {
                runCatching {
                    val targetDir = getApplication<Application>().getExternalFilesDir(null)
                        ?: error("Нет доступа к внешнему хранилищу приложения")
                    val targetFile = File(targetDir, "install_temp.apk")

                    val opened = contentResolver.openInputStream(uri)
                        ?: error("Не удалось открыть выбранный файл")
                    opened.use { input ->
                        targetFile.outputStream().use { output -> input.copyTo(output) }
                    }

                    val result = repository.installApk(targetFile).getOrThrow()
                    targetFile.delete()
                    result
                }
            }

            _installResult.value = outcome.fold(
                onSuccess = { output ->
                    if (output.contains("Success", ignoreCase = true)) {
                        "Установлено успешно ✅"
                    } else {
                        "Результат: ${output.trim()}"
                    }
                },
                onFailure = { "Ошибка установки: ${it.message}" },
            )
            _isInstalling.value = false
        }
    }
}
